/*************************************************************************
Cuyamaca College CS-181

File name:Add Line Numbers to File Data 	Add Line Numbers to File Data.cpp

Description: Lab #10, Exercise #1, Brief description of exercise: Write a program that asks the user for the name of a file. 
The program must display the contents of the file on the screen. 
Each line of screen output must be preceded with a line number, followed by a colon. 
The line numbering should start at 1. Note the sample program output below. 

Developer: Aiden Sakat


*************************************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	int lines = 0;
	int i = 1;
	string word;
	char filename[50];
	ifstream file;
	cout << "Please enter the filename:" << endl;;
	cin.getline(filename, 50);				// C:\Users\User\Downloads\Teams.txt
	
	file.open(filename);
	if (!file.is_open())
	{
		cout << "Invalid Filename.";
		exit(0);
	}
	
		if (file.is_open())
		{
			while (getline(file, word) && lines < 24)
			{
					cout << i++ << " : " << word << endl;
					lines++;

			}
			cout << "Press ENTER to continue...";
			cin.ignore();
			while (getline(file, word) && lines < INFINITY)
			{
				cout << i++ << ": " << word << endl;
				lines++;
			}
		}
}