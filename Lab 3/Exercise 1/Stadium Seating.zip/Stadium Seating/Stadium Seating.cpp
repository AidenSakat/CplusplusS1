// Stadium Seating.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	float CA, CB, CC, total;

	// amount of tickets sold for class A
	cout << "Class A tickets sold: ";
	cin >> CA;

	// amount of tickets sold for class B
	cout << "Class B tickets sold: ";
	cin >> CB;

	// amount of tickets sold for class C
	cout << "Class C tickets sold: ";
	cin >> CC;

	// equation to find the total income of all the tickets together
	total = 15 * CA + 12 * CB + 9 * CC;

	// total income of every ticket added up together
	cout << "Total income from sale of tickets: $" << setprecision(2) << fixed << total << endl;
	return 0;
}

