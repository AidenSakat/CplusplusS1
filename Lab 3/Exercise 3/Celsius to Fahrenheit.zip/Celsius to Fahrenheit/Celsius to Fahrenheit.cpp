// Celsius to Fahrenheit.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	//C = Celsius
	float C;

		cout << "Enter the temperature in Celsius: ";
	cin >> C;
	
	// F = Fahrenheit
	float F = 9.0 / 5.0 * C + 32.0;
	
	cout << setprecision(1) << fixed << F;
	cout << " Degrees Fahrenheit.";

	return 0;
}
