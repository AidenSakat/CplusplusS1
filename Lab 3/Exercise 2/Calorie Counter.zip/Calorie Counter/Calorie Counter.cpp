// Calorie Counter.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	// CPC = calories per cookie
	int CPC = 1;

	cout << "How many cookies did you eat? ";
	cin >> CPC;

	// equation used to calculate the calories
	int total = 100 * CPC;

	cout << "You consumed ";
		cout << total;
		cout << " calories.";

		return 0;
}