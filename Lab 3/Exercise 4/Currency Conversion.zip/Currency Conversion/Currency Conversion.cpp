// Currency Conversion.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	double DOLLAR;

	cout << "Enter a dollar amount: ";
	cin >> DOLLAR;
	
	// This is the current exchange rate that I found on google
	float YEN_PER_DOLLAR = DOLLAR * 143.76,
		EUROS_PER_DOLLAR = DOLLAR * 1;

	cout << "\nConversion Results \n--------------\n";
	
	cout << setprecision(2) << fixed << YEN_PER_DOLLAR;
	cout << " Yen\n";

	cout << setprecision(2) << fixed << EUROS_PER_DOLLAR;
	cout << " Euros\n\n\n";

		return 0;
}