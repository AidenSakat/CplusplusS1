/*************************************************************************
Cuyamaca College CS-181

File name:Corporate Sales Data	    Corporate Sales Data.cpp

Description: Lab #9, Exercise #1, Brief description of exercise:Write a program that uses a structure named corpSales to store the following data about a company division

Developer: Aiden Sakat
*************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;


struct corpSales
{
    string divison;
    double salesQ1;
    double salesQ2;
    double salesQ3;
    double salesQ4;
    double totalannualsales;
    double avgquarterlysales;
};

int eastdivison(struct corpSales);
int westdivison(struct corpSales);
double avgeast(struct corpSales);
double avgwest(struct corpSales);
int main()
{

    corpSales East = {"East Divison"};
    corpSales West = {"West Divison"};

  East.totalannualsales = eastdivison(East);
  West.totalannualsales = westdivison(West);
    East.avgquarterlysales = avgeast(East);
    West.avgquarterlysales = avgwest(West);

    cout << "Total Annual Sales: " << endl;
    cout << East.divison << ": $" << East.totalannualsales << endl;
    cout << West.divison << ": $" << West.totalannualsales << endl;

    cout << "\nAverage Quarterly Sales: " << endl;
    cout << East.divison << ": $" << East.avgquarterlysales << endl;
    cout << West.divison << ": $" << West.avgquarterlysales << endl;
}

/**********************************************************************
Function name:	eastdivison

Purpose: 		gets data from east division then adds it to get the total

Inputs: 		corpSales East

Returns: 		East.totalannualsales

Revision history
Date 11/4/22 		By	Aiden Sakat
************************************************************************/
int eastdivison(corpSales East)
{
    cout << fixed << showpoint << setprecision(2);

    cout << "Enter the quarterly sales for the " << East.divison << endl;
    cout << "First quarter: ";
    cin >> East.salesQ1;
    cout << "Second quarter: ";
    cin >> East.salesQ2;
    cout << "Third quarter: ";
    cin >> East.salesQ3;
    cout << "Fourth quarter: ";
    cin >> East.salesQ4;
    cout << endl;
    return East.totalannualsales = East.salesQ1 + East.salesQ2 + East.salesQ3 + East.salesQ4;
   
}

/**********************************************************************
Function name:	westdivison

Purpose: 		gets data from west division then adds it to get the total

Inputs: 		corpSales West

Returns: 		West.totalannualsales

Revision history
Date 11/4/22 		By	Aiden Sakat
************************************************************************/
int westdivison(corpSales West)
{
    cout << fixed << showpoint << setprecision(2);
    cout << "Enter the quarterly sales for the " << West.divison << endl;
    cout << "First quarter: ";
    cin >> West.salesQ1;
    cout << "Second quarter: ";
    cin >> West.salesQ2;
    cout << "Third quarter: ";
    cin >> West.salesQ3;
    cout << "Fourth quarter: ";
    cin >> West.salesQ4;
    cout << endl;
   return West.totalannualsales = West.salesQ1 + West.salesQ2 + West.salesQ3 + West.salesQ4;
}
/**********************************************************************
Function name:	avgeast

Purpose: 		Recieves the total annual sales then divides by how many quarters there are to get average

Inputs: 		corpSales East

Returns: 		East.totalannualsales / 4

Revision history
Date 11/4/22 		By	Aiden Sakat
************************************************************************/
double avgeast(corpSales East)
{
    return East.totalannualsales / 4;
}
/**********************************************************************
Function name:	avgwest

Purpose: 		Recieves the total annual sales then divides by how many quarters there are to get average

Inputs: 		corpSales West

Returns: 		West.totalannualsales / 4

Revision history
Date 11/4/22 		By	Aiden Sakat
************************************************************************/
double avgwest(corpSales West)
{
    return West.totalannualsales / 4;
}
