/*************************************************************************
Cuyamaca College CS-181

File name:Car Class and Test Fixture 	Car Class and Test Fixture.cpp

Description: Lab #11, Exercise #1, Brief description of exercise:Demonstrate the class in a program that creates a Car object, 
displays make and model year, then calls the accelerate function 
five times. After each call to the accelerate function, get the current speed of the car and display it. 
Then, call the brake function five times. After each call to the brake function, get the current speed of the car and display it. 

Developer: Aiden Sakat
*************************************************************************/

#include <iostream>
#include <iomanip>
#include <istream>
#include <string>
using namespace std;

class Car
{
public:
	Car()
	{
		cout << "Make: ";
		getline(cin, make);
		cout << "Year model: ";
		cin >> yearmodel;
	
	}
	void brake()
	{
		speed -= 5;
	}
	void accelerate()
	{
		speed += 5;
	}
	int speed = 0;

private:
	int yearmodel;
	string make;
};
int main()
{
	Car car;
	cout << "Current speed: " << car.speed << endl;
	for (int i = 0; i < 5; i++)
	{
		car.accelerate();
		cout << "Accelerating..." << endl;
		cout << "Current speed: " << car.speed << endl;
	}
	for (int i = 0; i < 5; i++)
	{
		car.brake();
		cout << "Braking..." << endl;
		cout << "Current speed: " << car.speed << endl;
	}
}

/**********************************************************************
Function name:	accelerate()

Purpose: 		accelerates the car

Inputs: 		struct Car

Returns: 		Void

Revision history
Date 11/11/22		By	Aiden Sakat
************************************************************************/

/**********************************************************************
Function name:	brake()

Purpose: 		Brakes the car

Inputs: 		struct Car

Returns: 		Void

Revision history
Date 11/11/22		By	Aiden Sakat
************************************************************************/
