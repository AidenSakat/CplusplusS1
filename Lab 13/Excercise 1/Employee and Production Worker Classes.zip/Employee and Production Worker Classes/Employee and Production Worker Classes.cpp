/*************************************************************************
Cuyamaca College CS-181

File name:Employee and Production Worker Classes	Employee and Production Worker Classes.cpp

Description: Lab #13, Exercise #1, Brief description of exercise:Write a program that about an Employee workday.

Developer: Aiden Sakat
*************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Employee
{
public:
	string name;
	string number;
	string hiredate;
	string day;

	void setname(string NAME)
	{
		name = NAME;
	}
	string getname()
	{
		return name;
	}

	void setnumber(string NUMBER)
	{
		number = NUMBER;
	}
	string getnumber()
	{
		return number;
	}

	void sethiredate(string HIREDATE)
	{
		hiredate = HIREDATE;
	}
	string gethiredate()
	{
		return hiredate;
	}
	void setday(string DAY)
	{
		day = DAY;
	}
	string getday()
	{
		return day;
	}
};

class ProductionWorker : public Employee
{
public:
	int shift;
	double hourlypay;


	ProductionWorker(string NA, string NU, string HI, string DA, int SH, double HO)
	{
		setname(NA);
		setnumber(NU);
		sethiredate(HI);
		setshift(SH);
		sethourlypay(HO);
		setday(DA);
	}

	 void setshift(int SHIFT)
	 {
		 shift = SHIFT;
	 }
	 int getshift()
	 {
		 return shift;
	 }

	 void sethourlypay(double HOURLYPAY)
	 {
		 hourlypay = HOURLYPAY;
	 }

	 double gethourlypay()
	 {
		 return hourlypay;
	 }

/**********************************************************************
Function name:	print

Purpose: 		prints the information

Inputs: 		

Returns: 		void

Revision history
Date 12/5		By	Aiden Sakat	
************************************************************************/
	void print()
	{
		cout << "Name: "<< name << endl;
		cout << "Employee number: " << number << endl;
		cout << "Hire date: " << hiredate << endl;
		cout << "Shift: " << day << endl;
		cout << "Shift number: " << shift << endl;
		cout << setprecision(2) << fixed << "Pay rate: " << hourlypay << endl;
	}

};

int main()
{
	ProductionWorker pw1("John Smith", "123", "10/12/2010", "Day", 1, 18.00);
	pw1.print();

	ProductionWorker pw2("Rob Smith", "321", "12/10/2010", "Night", 2, 18.00);
	cout << endl;
	pw2.print();

}

