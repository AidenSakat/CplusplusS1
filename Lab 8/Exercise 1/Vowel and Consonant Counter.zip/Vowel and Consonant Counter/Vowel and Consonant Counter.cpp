/*************************************************************************
Cuyamaca College CS-181

File name:Vowel and Consonant Counter 	 Vowel and Consonant Counter.cpp

Description: Lab #8, Exercise #1, Brief description of exercise:Write a function that accepts a pointer to a C-string as its argument. 
The function should count the number of vowels appearing in the string and return that number. 

Developer: Aiden Sakat
*************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
const int SIZE = 81;
char* getinfo(string);
void options();
char vowel(char*);
char consonant(char*);
int main()
{
	const string PROMPT = "Enter a string: ";
	int vowels, consonants{};
	vowels = consonants = 0;
	char option = 0;
	char* cstring = getinfo(PROMPT);
	int v = vowel(cstring);
	int c = consonant(cstring);
	options();
	cin >> option;
	while (true)
	{
		while (option == 'a' || option == 'A')
		{
			cout << "the string has " << v << " vowels" << endl;
			options();
			cin >> option;
		}
		while (option == 'b' || option == 'B')
		{
			cout << "the string has " << c << " consonants" << endl;
			options();
			cin >> option;
		}
		while (option == 'c' || option == 'C')
		{
			cout << "The string has " << v << " vowels" << " and " << c << " consonants" << endl;
			options();
			cin >> option;
		}
		while (option == 'd' || option == 'D')
		{
			cstring = getinfo(PROMPT);
			int v = vowel(cstring);
			int c = consonant(cstring);
			cin >> option;
		}
		while (option == 'e' || option == 'E')
		{
			cout << "Goodbye!" << endl;
			exit(0);
		}
		while (option != 'a' && option != 'A' && option != 'b' && option != 'B' && option != 'c'
			&& option != 'C' && option != 'd' && option != 'D' && option != 'e' && option != 'E')
		{
			cout << "Please enter A, B, C, D, or E\n" << endl;
			options();
			cin >> option;
		}

	}
	return 0;
}

/**********************************************************************
Function name:	getinfo

Purpose: 		gets the string from user

Inputs: 		string prompt

Returns: 		Returns line

Revision history
Date 11/1/22		By	Aiden Sakat	
************************************************************************/
char* getinfo(string prompt)
{
	static char line[SIZE];
	cout << prompt;
	cin.getline(line, SIZE);
	return line;
}

/**********************************************************************
Function name:	options

Purpose: 		Just displays options for a cleaner look

Inputs: 		

Returns: 		Void

Revision history
Date 10/28/22		By	Aiden Sakat
************************************************************************/
void options()
{
	cout << "\tA) Count the vowels in the string" << endl;
	cout << "\tB) Count the consonants in the string" << endl;
	cout << "\tC) Count both vowels and consonants" << endl;
	cout << "\tD) Enter another string" << endl;
	cout << "\tE) Exit this program" << endl;
	cout << "\n\tEnter A, B, C, D, or E." << endl;
}

/**********************************************************************
Function name:	vowel

Purpose: 		Counts the vowels from the string

Inputs: 		char* cstring

Returns: 		Returns vowels

Revision history
Date 10/28/22		By	Aiden Sakat
************************************************************************/
char vowel(char* cstring)
{
	int vowels = 0, consonants = 0;
	for (int i = 0; cstring[i] != '\0'; i++)
	{
		if (cstring[i] == 'a' || cstring[i] == 'e' || cstring[i] == 'i' || cstring[i] == 'o' || cstring[i] == 'u' ||
			cstring[i] == 'A' || cstring[i] == 'E' || cstring[i] == 'I' || cstring[i] == 'O' || cstring[i] == 'U')
		{
			vowels++;
		}
		else if ((cstring[i] >= 'a' && cstring[i] <= 'z') || (cstring[i] >= 'A' && cstring[i] <= 'Z'))
		{
			consonants++;
		}
	}
	return vowels;
}

/**********************************************************************
Function name:	consonant

Purpose: 		Counts the consonants from the string

Inputs: 		char* cstring

Returns: 		Returns consonants

Revision history
Date 10/28/22		By	Aiden Sakat
************************************************************************/
char consonant(char* cstring)
{
	int vowels = 0, consonants = 0;
	for (int i = 0; cstring[i] != '\0'; i++)
	{
		if (cstring[i] == 'a' || cstring[i] == 'e' || cstring[i] == 'i' || cstring[i] == 'o' || cstring[i] == 'u' ||
			cstring[i] == 'A' || cstring[i] == 'E' || cstring[i] == 'I' || cstring[i] == 'O' || cstring[i] == 'U')
		{
			vowels++;
		}
		else if ((cstring[i] >= 'a' && cstring[i] <= 'z') || (cstring[i] >= 'A' && cstring[i] <= 'Z'))
		{
			consonants++;
		}
	}
	return consonants;
}
