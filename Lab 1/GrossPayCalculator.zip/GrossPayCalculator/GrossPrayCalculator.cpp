// GrossPrayCalculator.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	double hours;
	double rate;
	double pay;

	// Get the number of hours worked.
	cout << "How many hours did you work ? ";
	cin >> hours;

	// Get the hourly pay rate.
	cout << "How much do you get paid per hour? ";
	cin >> rate;

	// Calculate the pay.
	pay = hours * rate;

	// Display the pay.
	cout << "You have earned $" << pay << endl;
	return 0;

}
