/*************************************************************************
Cuyamaca College CS-181

File name:Numbers Class and Test Fixture	Numbers Class and Test Fixture.cpp

Description: Lab #4, Exercise #4, Brief description of exercise:Design a class Numbers that can be used to 
translate whole dollar amounts in the range 0 through 9999 into an English description of the number. 
 
Developer: Aiden Sakat
*************************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
int number = 0;
string lessThan20[] = { ""," one"," two", " three", " four", " five", " six", " seven", " eight", " nine", " ten", " eleven", " twelve", " thirteen", " fourteen"
, " fifteen", " sixteen", " seventeen", " eighteen", " nineteen"};
string tens[] = { " twenty", " thirty", " forty", " fifty", " sixty", " seventy", " eighty", " ninety" };
string hundreds[] = { " one hundred", " two hundred", " three hundred", " four hundred", " five hundred", " six hundred", " seven hundred", " eight hundred", " nine hundred" };
string thousands[] = { "one thousand", "two thousand", "three thousand", "four thousand", "five thousand", "six thousand", "seven thousand", "eight thousand", "nine thousand" };

class Number
{
	public:
		Number(int num)
	{
			cout << "This program translates whole dollar amounts" << endl;
			cout << "in the range 0 through 9999 into an English" << endl;
			cout << "description of the number." << endl;
	}
		/**********************************************************************
	Function name:	print()

	Purpose: 		Prints the english description of the number

	Inputs: 		

	Returns: 		void

	Revision history
	Date 11/16/22	By	Aiden Sakat	
	************************************************************************/
		void print()
		{
			if (number == 0)
			{
				cout << " zero";
			}
			if (number >= 1000)
			{
				cout << thousands[(number / 1000) - 1];
				number %= 1000;
			}
			if (number >= 100)
			{
				cout << hundreds[(number / 100) - 1];
				number %= 100;
			}
			if (number >= 20)
			{
				cout << tens[(number / 10) - 2];
				number %= 10;
			}
			if (number >= 0 && number <= 20)
			{
				cout << lessThan20[(number)];
			}
		}
};
int main()
{
	Number number1(number);
	cout << "\nEnter a whole dollar amount: ";
	cin >> number;
	cout << "The English description is: "; 
	number1.print();
	cout << endl;
}
