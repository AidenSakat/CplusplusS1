// Shipping Charges.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	float SHIPPING, MILES, KG, total;
	
	cout << "Weight of the package in kilograms (max 20 Kg): "; 
	cin >> KG;
	cout << "Distance the package is to be shipped (10 - 3000 Miles): ";
	cin >> MILES;

	cout << setprecision(2) << fixed;

	// Error Codes
	if (MILES >= -INFINITY && MILES <= 9.999)
		cout  << "\nERROR!\nWe only ship 10-3000 miles";
	else if (MILES >= 3000.001 && MILES <= INFINITY)
		cout << "\nERROR!\nWe only ship 10-3000 miles";


	 else if (KG >= -INFINITY && KG <= 0)
		 cout << "\nERROR!\nWe only ship 0-20kg";

	 else if (KG >= 0 && KG <= 2)
			cout << "\nThe shipping charge is $"
			<< 1.10 + (int(MILES - 1) / 500) * 1.10;

		else if (KG >= 2 && KG <= 6)
			cout << "\nThe shipping charge is $"
			<< 2.20 + (int(MILES - 1) / 500) * 2.20;

		else if (KG >= 6 && KG <= 10)
			cout << "\nThe shipping charge is $"
			<< 3.7 + (int(MILES - 1) / 500) * 3.70;

		else if (KG >= 10 && KG <= 20)
			cout << "\nThe shipping charge is $"
			<< 4.8 + (int(MILES - 1) / 500) * 4.80;
		
		else if (KG >= 20 && KG <= INFINITY)
			cout << "\nERROR!\nWe only ship 0-20kg";

	
	return 0;
}

