// Body Mass Index.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int Pounds, Inches;

	cout << "Enter your weight in pounds: "; 
	cin >> Pounds;
	cout << "Enter your height in inches "; 
	cin >> Inches;

	// equation used for BMI
	float BMI = Pounds * 703 / pow(Inches, 2);
	
	cout << "Your BMI is ";
	cout << setprecision(2) << fixed << BMI << endl;

	if (BMI >= 0 && BMI <= 18.5)
		cout << "You are underweight." << endl;
	else if (BMI >= 18.5 && BMI <= 24.9)
		cout << "Your weight is normal." << endl;
	else if (BMI >= 25 && BMI <= 29.9)
		cout << "You are overweight." << endl;
	else if (BMI >= 30 && BMI <= INFINITY)
		cout << "You are obese." << endl;

	return 0;
}

