// Roman Numeral Converter.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	int DN;

cout << "Convert a decimal number to its Roman numeral equivalent\n";
	cout << "Enter a number between 1 and 10: "; cin >> DN;

	switch (DN)
	{
	case 1 : cout << "The Roman numeral version of " << DN << " is I.\n";
		break;
	case 2 : cout << "The Roman numeral version of " << DN << " is II.\n";
		break;
	case 3 : cout << "The Roman numeral version of " << DN << " is III.\n";
		break;
	case 4 : cout << "The Roman numeral version of " << DN << " is IV.\n";
		break;
	case 5 : cout << "The Roman numeral version of " << DN << " is V.\n";
		break;
	case 6 : cout << "The Roman numeral version of " << DN << " is VI.\n";
		break;
	case 7 : cout << "The Roman numeral version of " << DN << " is VII.\n";
		break;
	case 8 : cout << "The Roman numeral version of " << DN << " is VIII.\n";
		break;
	case 9 : cout << "The Roman numeral version of " << DN << " is IX.\n";
		break;
	case 10 : cout << "The Roman numeral version of " << DN << " is X.\n";

	default:	cout << "Your input must be between 1 and 10\n"; cin >> DN;
	}
	return 0;
}
