// Software Sales.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>

using namespace std;
int main()
{
	float PACKAGE_PRICE = 99,
		 UNITS_SOLD, total;

	cout << "How many units were sold? "; 
	cin >> UNITS_SOLD;

	total = PACKAGE_PRICE * UNITS_SOLD;

	cout << setprecision(2) << fixed;

	if (UNITS_SOLD >= 1 && UNITS_SOLD <= 9)
		cout << "The total cost of the purchase is $"
		<< total;
	else if (UNITS_SOLD >= 10 && UNITS_SOLD <= 19)
		cout << "The total cost of the purchase is $"
		<< total * .80;
	else if (UNITS_SOLD >= 20 && UNITS_SOLD <= 49)
		cout << "The total cost of the purchase is $"
		<< total * .70;
	else if (UNITS_SOLD >= 50 && UNITS_SOLD <= 99)
		cout << "The total cost of the purchase is $"
		<< total * .60;
	else if (UNITS_SOLD >= 100 && UNITS_SOLD <= INFINITY)
		cout << "The total cost of the purchase is $"
		<< total * .50;
	else if (UNITS_SOLD >= -INFINITY && UNITS_SOLD <= 0)
		cout << "INVALID! \nInput must be greater than 0\n";
	return 0;


}