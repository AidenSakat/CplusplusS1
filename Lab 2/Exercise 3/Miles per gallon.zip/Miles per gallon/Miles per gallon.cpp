// Miles per gallon.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	//miles driven till refuel
	 const double milesdriven = 400,
	// gallons of gas
		gallonsofgas = 15.0,
		total = milesdriven / gallonsofgas;

	cout << "Miles per gallon is " << total << endl;
	return 0;
}