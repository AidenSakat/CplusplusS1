// Annual Pay.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int payAmount = 2200,
		payPeriods = 26,
		annualPay = payAmount * payPeriods;

		cout << "Annual salary is: $" << annualPay << endl;
	return 0;
}