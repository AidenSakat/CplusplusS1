// Stock Commission.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	// SPP = stock purchase price
	const float Commissionpercent = 0.02;

	int SPP = 35.0,
		shares = 750 + 0.5,
		totalshares = shares * SPP,
		Commiss = totalshares * Commissionpercent,
		total = totalshares + Commiss;


	cout << "Stock purchase price $: " << totalshares << endl;

	cout << "Commission $: " << Commiss << endl;

	cout << "Total $: " << total << endl;


}