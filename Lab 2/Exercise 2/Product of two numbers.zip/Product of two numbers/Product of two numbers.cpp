// Product of two numbers.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{
	int fifty = 50,
		onehundred = 100,
		total = fifty * onehundred;

	cout << "The total is " << total << endl;
	return 0;
}