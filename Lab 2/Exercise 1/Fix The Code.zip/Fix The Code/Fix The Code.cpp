// Fix The Code.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
using namespace std;
int main()
{
	// A crazy mixed up program
cout << "In 1492 Colombus sailed the ocean blue." << endl;
return 0;
}